import React from "react";

const MyAccount = () => {
    return (
        <aside className="">
            
        </aside>
    )
}

export default MyAccount;